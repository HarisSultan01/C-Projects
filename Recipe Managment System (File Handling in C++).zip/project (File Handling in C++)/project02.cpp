#include <iostream>
#include <fstream>
#include <string>
#include "insertion.hpp"
using namespace std;

string recipe1(string recipeName)
{
	string line;
	ifstream recipeFile("Italian.txt"); // read mode
	if (recipeFile.is_open())
	{
		while (getline(recipeFile, line))
		{
			if (line == recipeName)
			{
				cout << "Recipe for " << recipeName << ":\n";
				while (getline(recipeFile, line) && line != " ")
				{
					cout << line << '\n';
				}
				break;
			}
		}
		recipeFile.close();
	}
	else
	{
		cout << "Unable to open file";
	}
}
string recipe2(string recipeName)
{
	string line;
	ifstream recipeFile("FastFood.txt");
	if (recipeFile.is_open())
	{
		while (getline(recipeFile, line))
		{
			if (line == recipeName)
			{
				cout << "Recipe for " << recipeName << ":\n";
				while (getline(recipeFile, line) && line != "")
				{
					cout << line << '\n';
				}
				break;
			}
		}
		recipeFile.close();
	}
	else
	{
		cout << "Unable to open file";
	}
}
string recipe3(string recipeName)
{
	string line;
	ifstream recipeFile("Dessert.txt"); // read
	if (recipeFile.is_open())
	{
		while (getline(recipeFile, line))
		{
			if (line == recipeName)
			{
				cout << "Recipe for " << recipeName << ":\n";
				while (getline(recipeFile, line) && line != "")
				{
					cout << line << '\n';
				}
				break;
			}
		}
		recipeFile.close();
	}
	else
	{
		cout << "Unable to open file";
	}
}

int main()
{
	int CHeck=0;
	do
	{
		cout<<"Enter 1 to Enter the new recipe 0 for move forward";
		cin>>CHeck;
		if (CHeck==1)
		{
			insert();
		}
		if (CHeck!=1)
		{
			break;
		}
	}while(CHeck==0);
	string recipeName;
	string line;
	int recipetype;
	int check=0;
	do
	{
		cout << "\nEnter 1 for Italian" << endl;
		cout << "Enter 2 for Fast-food" << endl;
		cout << "Enter 3 for Dessert" << endl;
		cout << "Enter the recipe type: " << endl;
		cin >> recipetype;
		if (recipetype == 1 || recipetype == 2 || recipetype == 3)
		{
			cin.ignore();
			check = 1;
		}
		else
		{
			cout << "invalid recipe type" << endl;
		}
	} while (check == 0);
	// categrize the food type

	if (recipetype == 1)
	{
		cout << "*******Menu*******" << endl;
		cout << "Suggestion" << endl;
		cout << "Fried Fish, Veggie Fajita, Pasta" << endl;
		string str1 = "Fried Fish";
		string str2 = "Veggie Fajita";
		string str3 = "Pasta";
		check = 0;
		do
		{
			cout << "Enter the recipe name: ";
			getline(cin, recipeName);
			int res = recipeName.compare(str1);
			int re = recipeName.compare(str2);
			int result = recipeName.compare(str3);
			if (res == 0 || re == 0 || result == 0)
			{
				check = 1;
				string line1 = recipe1(recipeName);
				cout << line1;
			}
			else
			{
				cout << "You Enterd wrong recipe Name" << endl;
				cout << "re-enter the the detail's again :)" << endl;
			}
			cout << endl;
		} while (check == 0);
	}
	else if (recipetype == 2)
	{
		cout << "*******Menu*******" << endl;
		cout << "Suggestion" << endl;
		cout << "Shawarma, Hamburger" << endl;
		check = 0;
		do
		{
			cout << "Enter the recipe name: ";
			getline(cin, recipeName);
			string str4 = "Shawarma";
			string str5 = "Hamburger";
			int RES1 = str4.compare(recipeName);
			int RES2 = str5.compare(recipeName);

			if (RES1 == 0 || RES2 == 0)
			{
				check = 1;
				string line2 = recipe2(recipeName);
				cout << line2 << endl;
			}
			else
			{
				cout << "You Enterd wrong recipe Name" << endl;
				cout << "re-enter the the detail's again :)" << endl;
			}
		} while (check == 0);
	}
	else if (recipetype == 3)
	{
		cout << "*******Menu*******" << endl;
		cout << "Dessert Suggestion:" << endl;
		cout << "Icecream, Pancake: " << endl;
		check=0;
		do
		{
			cout << "Enter the recipe name: ";
			getline(cin, recipeName);
			string str6 = "Icecream";
			string str7 = "Pancake";
			int Res1 = str6.compare(recipeName);
			int Res2 = str7.compare(recipeName);
			if (Res1 == 0 || Res2 == 0)
			{
				check = 1;
				string Line3 = recipe3(recipeName);
				cout << Line3 ;
			}
			else
			{
				cout << "You Enterd wrong recipe Name" << endl;
				cout << "re-enter the the detail's again :)" << endl;
			}
		} while (check == 0);
	}

	return 0;
}