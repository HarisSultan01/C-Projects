#include <iostream>
#include <string>
#include <fstream>
using namespace std;
string insert() // to insert more data/recepie
{
   cin.ignore();
   string line;
   string filename,output;
   fstream newfile;
   fstream myfile;
       
   cout << "Dessert,FastFood,Italian" << endl;
   cout << "Enter above mentioned file name to add more recipe in them" << endl;
   cout << "You can also create new file name: ";
   getline(cin, filename);
   string filename_with_extension = filename + ".txt";
   myfile.open(filename_with_extension, ios::app);
   {
      if (myfile.is_open())
      {
         cout << "Enter the Data for recipe: " << endl;
         myfile << "\r";
         while (getline(cin, line) && !line.empty())
         {
            myfile << line;
            myfile << "\r";
         }
         cout << "The New Recipe is sucessfully stored  ";
      }
      else
      {
         cout << "The file doesn't open yet!";
      }
      myfile.close();
   }
}